# Discord-Webhook-IP-Logger
This is a PHP IP logger I made that sends the IP's to a Discord webhook.  
# Features
- Grabs the IP then gets info about it after that it sends it to a webhook you have entered in the file.  
- Gets Geo Location & ISP aswell as information regarding if its a VPN/Home Connection  
- Filters out bots/site crawlers  
# How to use
Step 1: Go into the settings of your Discord server, click webhooks and create one then copy the link to it.  
Step 2: Put in the field of `$webhookurl = "";` with https://discordapp.com/api/webhooks/ included at the beginning.
<br>Step 3: Upload the file to your website (you can use external webhosting such as 000webhost if you dont have a website/domain)

# Changelog
Version: v1
<br>Information: I will be updating this for better use in the future.

# Developer
I, ᴮᵉᵗᵗᵉʳ ᴼᶠᶠ ᴳᵒⁿᵉ#0869, am the original creator of this IP Logger-Discord Webhook,
Please don't try to take credit for my coding, please keep the copyright header intact,
This code is licensed under the GNU License, but please respect the original developer of this code (me)
